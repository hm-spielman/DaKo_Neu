package hm.edu.dako.chatServer;

public class ChatServerStarter {
    public static void main(String[] args) {
        ChatServerGUI.main(args);
    }
}
