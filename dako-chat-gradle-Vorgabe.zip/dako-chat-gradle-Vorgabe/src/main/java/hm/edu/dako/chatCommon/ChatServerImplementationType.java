package hm.edu.dako.chatCommon;

/**
 * Implementierungsvarianten des ChatServers mit verschiedenen Transportprotokollen
 * @author Mandl
 */

public enum ChatServerImplementationType {
    TCPAdvancedImplementation, TCPSimpleImplementation, UDPAdvancedImplementation,
}
