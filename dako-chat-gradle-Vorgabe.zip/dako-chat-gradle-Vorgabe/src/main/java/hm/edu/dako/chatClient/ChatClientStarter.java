package hm.edu.dako.chatClient;

public class ChatClientStarter {
    public static void main(String[] args) {
        ClientFxGUI.main(args);
    }
}
