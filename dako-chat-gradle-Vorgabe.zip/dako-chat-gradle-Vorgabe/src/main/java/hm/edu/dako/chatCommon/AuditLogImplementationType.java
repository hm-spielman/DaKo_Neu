package hm.edu.dako.chatCommon;

/**
 * Implementierungsvarianten des Lasttests mit verschiedenen Transportprotokollen
 * @author Mandl
 */

public enum AuditLogImplementationType {
    AuditLogServerTCPImplementation, AuditLogServerUDPImplementation,
}
