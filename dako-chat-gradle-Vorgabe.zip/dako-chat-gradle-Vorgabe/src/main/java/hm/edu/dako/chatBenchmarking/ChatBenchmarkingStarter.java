package hm.edu.dako.chatBenchmarking;

public class ChatBenchmarkingStarter {
    public static void main(String[] args) {
        BenchmarkingClientFxGUI.main(args);
    }
}
